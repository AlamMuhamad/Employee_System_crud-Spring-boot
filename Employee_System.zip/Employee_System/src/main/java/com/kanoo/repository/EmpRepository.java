package com.kanoo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kanoo.entity.Employee;

public interface EmpRepository extends JpaRepository<Employee, Integer>{

}
