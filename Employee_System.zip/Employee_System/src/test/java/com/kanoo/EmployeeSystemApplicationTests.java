package com.kanoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
